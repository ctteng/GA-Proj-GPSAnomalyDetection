mplexporter
===========

A proof of concept general matplotlib exporter
